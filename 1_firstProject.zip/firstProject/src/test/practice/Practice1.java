package test.practice;

import java.util.*;

public class Practice1 {
	public static void main(String[] args) {
		String name = "홍길동";
		int age = 25;
		String phone = "010-1234-5678";
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("연락처 : " + phone);
	}
}