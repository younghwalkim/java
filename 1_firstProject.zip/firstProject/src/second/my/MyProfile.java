package second.my;

public class MyProfile {

	public static void main(String[] args) {
		// 본인 소개 문구를 콘솔에 출력하는 구문을 완성해 보시오.
		System.out.println("이 름 : 홍길순");
		System.out.println("성 별 : 여자");
		System.out.println("나 이 : 25 세");
		System.out.println("거주지 : 서울시 서초구 신논현 111");

	}

}
