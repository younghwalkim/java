//첫줄에는 반드시 패키지 선언문 작성함 : package 패키지명.패키지명;
package second.my;

//필요할 경우 import 선언문 작성함 : import 소속패키지명.클래스명;

//클래스 작성부 : public class 클래스명 {}
public class Test {
	//실행용 클래스가 되려면, main 메소드가 있어야 함
	//자바의 main 메소드 시그니처는 정해져 있음
	public static void main(String[] args) {
		System.out.println("Test 클래스 작동 확인");
	}
}