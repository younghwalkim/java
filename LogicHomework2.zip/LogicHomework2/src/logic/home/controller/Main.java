package logic.home.controller;

import logic.home.model.NonStaticMethodSample;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NonStaticMethodSample samp = new NonStaticMethodSample();
		samp.testDate();
	}

}
