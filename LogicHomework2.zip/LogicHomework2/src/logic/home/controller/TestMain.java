package logic.home.controller;

import logic.home.view.Menu;

public class TestMain {

	public static void main(String[] args) {
		// 제어문 과제2 실행용
		Menu.mainMenu();
		System.out.println("\n제어문 과제 프로그램을 종료합니다.");
	}

}
